<div align="center">

<img src="icon-512.png" alt="ALTRA-DAWNLOADER" width="120" height="120">

# ALTRA-DAWNLOADER

**محمّل وسائط مستقل وقابل للتثبيت · Independent, installable media downloader**

[![Live App](https://img.shields.io/badge/Live%20App-افتح%20التطبيق-00d2ff?style=for-the-badge&logo=googlechrome&logoColor=white)](https://nidal-watfa99.github.io/)
[![Version](https://img.shields.io/badge/version-8.6-00ff88?style=for-the-badge)](#)
[![PWA](https://img.shields.io/badge/PWA-installable-5a0fc8?style=for-the-badge&logo=pwa&logoColor=white)](#-التثبيت)
[![License: MIT](https://img.shields.io/badge/License-MIT-ff9f43?style=for-the-badge)](LICENSE)

[**🚀 افتح التطبيق**](https://nidal-watfa99.github.io/) ·
[**📦 المستودع**](https://github.com/nidal-watfa99/nidal-watfa99.github.io) ·
[**✉️ تواصل**](#-التواصل-والحسابات)

</div>

---

## 🌐 الروابط

| | الرابط |
|---|---|
| **التطبيق المباشر** | https://nidal-watfa99.github.io/ |
| **المستودع** | https://github.com/nidal-watfa99/nidal-watfa99.github.io |

---

## ✨ نبذة

**ALTRA-DAWNLOADER** تطبيق ويب تقدّمي (PWA) لتحميل الفيديو والصوت بصيغ متعددة، بحد أقصى **10 مهام متزامنة**.
يعمل مباشرة من المتصفح، ويُثبَّت على الهاتف أو سطح المكتب كتطبيق مستقل، ولا يحتاج إلى حساب أو تسجيل.

- ملفات واجهة ثابتة فقط: `HTML + CSS + JavaScript`، بلا أي اعتماد على أطر عمل أو خادم خلفي.
- كل الإعدادات والسجل تُحفظ محليًا على جهازك.
- واجهة عربية بالكامل بتصميم داكن يدعم الاتجاه من اليمين إلى اليسار.

## 🎯 المزايا

| الميزة | الوصف |
|---|---|
| ⚡ **تحميل فوري** | الصق الرابط واضغط GO، أو شاركه إلى التطبيق مباشرة |
| 🔗 **المشاركة إلى التطبيق** | من أي تطبيق على أندرويد: مشاركة ← ALTRA (Web Share Target) |
| 🔢 **حتى 10 مهام** | قائمة انتظار بتزامن قابل للضبط من 1 إلى 10 |
| 📁 **مجلد حفظ مخصص** | اختيار مجلد داخلي أو خارجي على المتصفحات الداعمة (File System Access API) |
| 🎚️ **جودة وصيغ** | من 360p إلى 4K، وصيغ MP4 وWEBM وMP3 وOGG وOPUS وWAV |
| 🔍 **بحث متقدم** | فلترة المهام والسجل حسب الكلمة والحالة والمنصة |
| 📊 **سجل وإحصائيات** | سجل التحميلات، مع تصدير بصيغة JSON |
| 📲 **قابل للتثبيت** | أيقونة على الشاشة الرئيسية، ويعمل بوضع ملء الشاشة |
| 🛠️ **Console مدمج (زر ⌘)** | سجل مباشر لأخطاء التطبيق والمساعد (تتبع yt-dlp الكامل)، مع نسخ السجل بزر واحد و«🩺 تشخيص شامل» وأوامر `diag` و`help` و`status` و`queue` |
| 📤 **مشاركة التطبيق** | واتساب، تيليغرام، بريد، أو نسخ الرابط |

## 📲 التثبيت

### أندرويد (Chrome)
1. افتح الرابط: https://nidal-watfa99.github.io/
2. اضغط **⋮** ثم **تثبيت التطبيق** (أو **إضافة إلى الشاشة الرئيسية**).
3. بعد التثبيت ستظهر **ALTRA** في قائمة المشاركة داخل التطبيقات الأخرى.

### iPhone / iPad (Safari)
1. افتح الرابط في Safari.
2. اضغط **مشاركة** ثم **إضافة إلى الشاشة الرئيسية**.

### الكمبيوتر (Chrome / Edge)
1. افتح الرابط.
2. اضغط أيقونة التثبيت في شريط العنوان، أو **تثبيت** داخل التطبيق.

## 🚀 الاستخدام السريع

1. افتح التطبيق.
2. الصق رابطًا أو أكثر في الحقل، رابط في كل سطر.
3. اضغط **GO · ابدأ التحميل**.
4. تابع التقدم في **قائمة الانتظار**، واضغط **إلغاء** أو **إعادة** عند الحاجة.

> **اختصار:** `Ctrl + Enter` لبدء التحميل من الحقل على الكمبيوتر.

## 🧩 المساعد المحلي: تحميل من كل المواقع

المتصفحات تمنع أي موقع من استخراج روابط الفيديو من يوتيوب وإنستغرام وتيك توك (CORS وحمايات المواقع)،
ولا يمكن لتطبيق ويب ثابت تجاوز ذلك وحده. لذلك يتضمن المشروع **`altra-server.py`**،
وهو مساعد صغير يعمل **على جهازك أنت** ويستخدم [yt-dlp](https://github.com/yt-dlp/yt-dlp) (أكثر من 1000 موقع).
التطبيق يعتمد عليه أولًا، ثم يجرّب Cobalt، ثم الروابط المباشرة.

```text
التطبيق  ──رابط──▶  المساعد المحلي (yt-dlp + ffmpeg)  ──ملف──▶  تنزيل المتصفح
```

| نوع الرابط | المساعد | بدونه |
|---|:---:|:---:|
| ملف مباشر (`.mp4` `.mp3` …) | ✅ | ✅ |
| YouTube · Instagram · TikTok · Facebook · X · Reddit · SoundCloud … | ✅ | ❌ |
| دمج الفيديو والصوت، وتحويل MP3 وOGG وOPUS وWAV | ✅ (مع ffmpeg) | ❌ |

### أندرويد (Termux)
1. ثبّت **Termux** من [F-Droid](https://f-droid.org/packages/com.termux/).
2. الصق هذا الأمر مرة واحدة في Termux:
   ```bash
   curl -fsSL https://nidal-watfa99.github.io/setup-termux.sh | bash
   ```
3. اترك Termux يعمل، وافتح التطبيق: https://nidal-watfa99.github.io/
   فيتحول الشريط العلوي إلى 🟢 «المساعد المحلي متصل».
4. في المرات القادمة: اكتب `altra` في Termux.

> بدلًا من ذلك افتح **http://localhost:8787** وثبّت التطبيق من هناك، فيعمل مع المساعد دون أي إذن إضافي.
> وإن سأل Chrome عن «الوصول إلى الشبكة المحلية» عند فتح التطبيق من GitHub Pages فاختر **سماح**.

### الكمبيوتر
```bash
pip install -U "yt-dlp[default]"      # وثبّت ffmpeg
python altra-server.py                # ثم افتح http://localhost:8787
```
خيارات: `--port 9000` · `--cookies cookies.txt` · `--browser chrome` · `--host 0.0.0.0` (للشبكة المحلية).

### لوحة تحكم المساعد ⚙️
بعد تشغيل المساعد افتح **http://localhost:8787/dashboard** لرؤية:
- حالة الخادم ووقت التشغيل وعدد المهام وحجم الكاش
- قائمة كل المهام مع التقدم والإلغاء الفردي أو الجماعي
- مسح المهام المنتهية أو تفريغ الكاش بالكامل

### المحتوى الذي يطلب تسجيل الدخول 🔵
بعض مقاطع إنستغرام وفيسبوك (الخاصة أو المقيّدة) لا تظهر إلا لحساب مسجّل. عندها تظهر على المهمة شارة زرقاء **«مطلوب تسجيل الدخول»**. اضغطها:

1. **فتح صفحة تسجيل الدخول** في الموقع المعني وسجّل دخولك.
2. **صدّر جلسة الدخول (cookies) والصقها** في النافذة، فتُحفظ مرة واحدة ثم تُعاد المحاولة تلقائيًا.
   - **أندرويد:** متصفح **Firefox** مع إضافة **Cookie-Editor** ← Export ← JSON.
   - **الكمبيوتر:** إضافة «Get cookies.txt LOCALLY» ← الصق المحتوى أو اختر الملف.

المساعد برنامج منفصل عن المتصفح، ولذلك لا يكفي تسجيل الدخول في المتصفح وحده. الجلسة تبقى على جهازك داخل مجلد المساعد، ولا تُرسل لأي جهة،
ويُفضّل استخدام حساب ثانوي. يمكنك حذفها من نافذة «🔑 جلسة الدخول».

### الأمان
- المساعد يستمع على جهازك فقط (`127.0.0.1`) ويرفض أي موقع غير موثوق، والمسموح هو localhost ورابط تطبيقك على GitHub Pages.
- لا يقدّم إلا ملفات التطبيق (HTML/JS/PNG)، ولا يعرض ملف `cookies.txt` ولا أي ملف آخر.
- الملفات المؤقتة تُحذف تلقائيًا بعد ساعة وعند الإيقاف.

## 🧱 بنية المشروع

```text
ALTRA-DAWNLOADER/
├── index.html            # الواجهة والمنطق كاملًا
├── altra-server.py       # المساعد المحلي (yt-dlp) لتحميل يوتيوب وإنستغرام وغيرها
├── setup-termux.sh       # إعداد المساعد تلقائيًا على أندرويد
├── sw.js                 # Service Worker للعمل دون اتصال
├── manifest.webmanifest  # بيانات التثبيت والمشاركة إلى التطبيق
├── icon-192.png          # أيقونة التثبيت
├── icon-512.png          # أيقونة التثبيت الكبيرة
├── README.md
└── LICENSE
```

## 🛠️ التشغيل والتطوير محليًا

لا حاجة لبناء أو تثبيت حزم. يكفي خادم ملفات ثابتة:

```bash
git clone https://github.com/nidal-watfa99/nidal-watfa99.github.io.git
cd nidal-watfa99.github.io
python3 -m http.server 8080
```

ثم افتح `http://localhost:8080`. عنوان `localhost` يُعامَل كبيئة آمنة، فيعمل معه التثبيت والـ Service Worker.

## 🚢 النشر على GitHub Pages

1. افتح **Settings ← Pages**.
2. **Source:** Deploy from a branch.
3. **Branch:** `main` والمجلد `/ (root)` ثم **Save**.

## 🔧 استكشاف الأخطاء

| المشكلة | الحل |
|---|---|
| لا يظهر خيار التثبيت | تأكد أنك على رابط HTTPS، وجرّب تحديث الصفحة، ثم افتح قائمة المتصفح |
| تظهر «تعذّر الاتصال بالمصدر» | الموقع يمنع CORS أو أنك دون إنترنت؛ جرّب رابط ملف مباشر أو ضع خادمك الخاص |
| الروابط الاجتماعية تفشل | شغّل المساعد المحلي (الشريط العلوي أخضر 🟢)؛ خوادم Cobalt العامة غير موثوقة |
| شارة 🔵 «مطلوب تسجيل الدخول» | اضغطها واستورد جلسة حسابك كما في القسم أعلاه |
| الفيديو لا يظهر في المعرض | الملفات تُحفظ في **التنزيلات**؛ عطّل «Ask where to save files» في إعدادات تنزيلات Chrome |
| يوتيوب يفشل فجأة | حدّث yt-dlp: `pip install -U "yt-dlp[default]"` |
| التطبيق لا يحمّل التحديثات | أغلقه وأعد فتحه، أو امسح بيانات الموقع من إعدادات المتصفح |
| مجلد الحفظ لا يعمل | الميزة لـ Chrome وEdge على الكمبيوتر فقط؛ على الجوال يُحفظ في التنزيلات تلقائيًا |

اضغط زر **⌘** أعلى الشاشة لفتح Console، ثم **📋 نسخ السجل** وأرفقه عند التبليغ عن مشكلة.

## ⚖️ إخلاء المسؤولية

- هذا التطبيق أداة تقنية فقط، ولا يتجاوز حماية **DRM** ولا يخترق أي حماية.
- حمّل **المحتوى الذي يحق لك تحميله فقط**، والتزم بشروط كل منصة وبقوانين حقوق النشر في بلدك.
- المطوّر غير مسؤول عن أي استخدام مخالف.

## 🤝 المساهمة

المساهمات مرحّب بها:
1. اعمل **Fork** للمستودع.
2. أنشئ فرعًا للتعديل: `git checkout -b feature/اسم-الميزة`
3. أرسل **Pull Request** مع وصف واضح للتغيير.

كما يمكنك فتح **Issue** للاقتراحات أو الأخطاء.

## 📞 التواصل والحسابات

**نضال وطفة · Nidal Watfa**

| المنصة | الرابط |
|---|---|
| 📧 البريد | [nidalwatfa99@gmail.com](mailto:nidalwatfa99@gmail.com) |
| 💬 واتساب | [0096998854450](https://wa.me/96998854450) |
| ✈️ تيليغرام | [@nidal12watfa](https://t.me/nidal12watfa) |
| 🐙 GitHub | [nidal-watfa99](https://github.com/nidal-watfa99) |
| 🦊 GitLab | [danial-wq](https://gitlab.com/danial-wq) |
| 🌿 Codeberg | [nidalwatfa](https://codeberg.org/nidalwatfa) |
| 💼 LinkedIn | [nidal-watfa](https://www.linkedin.com/in/nidal-watfa-a91720301) |
| 𝕏 X | [@NidalWatfa12501](https://x.com/NidalWatfa12501) |
| 🎓 ORCID | [0009-0003-2462-6630](https://orcid.org/0009-0003-2462-6630) |

## 📄 الترخيص

مرخّص بموجب [رخصة MIT](LICENSE). © 2026 Nidal Watfa.

---

<div align="center">

### English summary

**ALTRA-DAWNLOADER** is a dependency-free, installable PWA media downloader: up to 10 concurrent tasks,
direct-file downloads with no server, Web Share Target support, custom save folder, history and advanced search.
Social platforms (YouTube, Instagram, TikTok…) require your own [Cobalt](https://github.com/imputnet/cobalt) server because browsers block extracting those links.

**[Open the app](https://nidal-watfa99.github.io/)** · Licensed under MIT.

</div>
